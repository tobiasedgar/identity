<?= css(['assets/css/swiper-bundle.min.css','assets/css/fonts.css','assets/css/style.css','@auto','assets/css/mobile.css','assets/css/aos.css']) ?>
