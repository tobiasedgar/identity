<?= js(['assets/js/aos.js','assets/js/uploadcare.min.js','assets/js/lazyload.min.js','assets/js/swiper-bundle.min.js','assets/js/lottie.js','assets/js/jquery.js','assets/js/main.js']) ?>
