<link class="js-dynamic-favicon" rel="apple-touch-icon-precomposed" sizes="57x57" href="/assets/favicon/apple-touch-icon-57x57.png" />
<link class="js-dynamic-favicon" rel="apple-touch-icon-precomposed" sizes="114x114" href="/assets/favicon/apple-touch-icon-114x114.png" />
<link class="js-dynamic-favicon" rel="apple-touch-icon-precomposed" sizes="72x72" href="/assets/favicon/apple-touch-icon-72x72.png" />
<link class="js-dynamic-favicon" rel="apple-touch-icon-precomposed" sizes="144x144" href="/assets/favicon/apple-touch-icon-144x144.png" />
<link class="js-dynamic-favicon" rel="apple-touch-icon-precomposed" sizes="120x120" href="/assets/favicon/apple-touch-icon-120x120.png" />
<link class="js-dynamic-favicon" rel="apple-touch-icon-precomposed" sizes="152x152" href="/assets/favicon/apple-touch-icon-152x152.png" />
<link class="js-dynamic-favicon" rel="icon" type="image/png" href="/assets/favicon/favicon-32x32.png"sizes="32x32" />
<link class="js-dynamic-favicon" rel="icon" type="image/png" href="/assets/favicon/favicon-16x16.png"sizes="16x16" />

<meta name="application-name" content="<?= $site->title() ?>"/>
<meta name="msapplication-TileColor" content="#000000" />
<meta name="msapplication-TileImage" content="/assets/favicon/mstile-144x144.png" />
