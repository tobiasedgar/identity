### 1.1.3
add ability to change/localise all strings showing in browser template
11 December 2019 at 4:50 pm AEDT

### 1.1.2
add fallback to language code for detailed locale configs
1 December 2019 at 11:10 am AEDT

### 1.1.1
add ability to handle detailed locale configs
30 November 2019 at 9:10 pm AEDT

### 1.1
add ability to use custom mapping function
enhance xsl stylesheet routing
improve docs and move them to wiki
22 November 2019 at 6:15 pm AEDT

### 1.0.5
fix composer.json due to failed deployment via Packagist
8 November 2019 at 1:45 pm AEDT

### 1.0.4
add ability to customise sitemap styling, and by-line.
8 November 2019 at 1:40 pm AEDT

### 1.0.3
add logic to skip untranslated pages in multilingual sites:
Sitemapper checks whether the page has a content file for the language,
and will only list the URL if the content file has been created.
7 November 2019 at 9:11:20 pm AEDT

### 1.0.2
add changelog, more doc corrections
7 November 2019 at 1:31:32 pm AEDT

### 1.0.1
minor changes to readme docs
7 November 2019 at 8:26:35 am AEDT

### 1.0
Initial release
7 November 2019 at 8:15:35 am AEDT
