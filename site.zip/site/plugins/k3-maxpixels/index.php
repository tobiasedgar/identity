<?php 

Kirby::plugin('rasteiner/k3-maxpixels-option', []);