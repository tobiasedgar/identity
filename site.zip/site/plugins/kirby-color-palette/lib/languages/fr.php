<?php

return array(
	'palette.new.palette'    => 'Nouveau nuancier',
	'palette.empty.options'  => 'Renseignez des couleurs dans votre blueprint.',
	'palette.empty.template' => 'Il n\'y a pour l\'instant aucune image à partir de laquelle extraire des couleurs.',
	'palette.empty.palette'  => 'Le nuancier est vide. Sélectionnez une image pour commencer l\'extraction.',
);