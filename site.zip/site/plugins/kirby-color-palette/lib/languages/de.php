<?php

return array(
	'palette.new.palette'    => 'Neue Palette',
	'palette.empty.options'  => 'Bitte geben Sie Farben in den Feldoptionen an.',
	'palette.empty.template' => 'Es gibt derzeit kein Bild, aus denen Farben extrahiert werden können.',
	'palette.empty.palette'  => 'Die Farbpalette ist leer. Bitte wählen Sie ein Bild aus.',
);