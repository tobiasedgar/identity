<?php

return array(
	'palette.new.palette'    => 'New palette',
	'palette.empty.options'  => 'Please specify colors in the field blueprint.',
	'palette.empty.template' => 'There is currently no image to extract colors from.',
	'palette.empty.palette'  => 'The color palette is empty. Please select an image.',
);