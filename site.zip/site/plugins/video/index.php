<?php

Kirby::plugin('skeletonkit/video-block', []);