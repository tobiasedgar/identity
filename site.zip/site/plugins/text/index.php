<?php

Kirby::plugin('skeletonkit/text-block', []);