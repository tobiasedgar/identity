<?php

Kirby::plugin('sylvainjule/previews', []);
