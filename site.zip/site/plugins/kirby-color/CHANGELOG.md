# Changelog
All notable changes to this project will be documented in this file.

## [1.0.1] - 2020-11-19
### Added
- This ChangeLog (Better late then never)
### Changed
- Readme: Installation Guide
### Fixed
- #14 fixed reverting new color field values
- #11 Fixed RGB and HLS input Fields when editableAlpha is set to false