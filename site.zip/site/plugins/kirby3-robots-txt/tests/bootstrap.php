<?php require_once __DIR__ . '/bootstrap.php';

$kirby = new Kirby();

echo $kirby->render();
