<?php

Kirby::plugin('skeletonkit/carousel-block', []);