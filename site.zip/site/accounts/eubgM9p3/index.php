<?php

return [
    'email' => 'hello@newterritory.studio',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];