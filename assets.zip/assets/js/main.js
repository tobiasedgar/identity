(function() {
    
  // uploadcare
  UPLOADCARE_LOCALE_TRANSLATIONS = {
    buttons: {
        choose: {
            files: {
                one: 'UPLOAD PHOTO'
            }
        }
    }
  }

  // opening 
  function opening() {
    var visited = sessionStorage['visited'];
    if (!visited) {
       init();
       sessionStorage['visited'] = true;
    }

    function init() {
      const ioOne = document.querySelector('.intro__overlay__one');
      const ioTwo = document.querySelector('.intro__overlay__two');
      const ioThree = document.querySelector('.intro__overlay__three');
      const ioText = document.querySelector('.intro__text');

      setTimeout(function() { 
        ioOne.classList.add('show');
        ioTwo.classList.add('show');
        ioThree.classList.add('show');
        ioText.classList.add('show');
       }, 0);

      setTimeout(function() {
        ioOne.classList.add('hide');
        ioOne.classList.remove('show');
       }, 1500);
    
       setTimeout(function() { 
        ioTwo.classList.add('hide');
        ioTwo.classList.remove('show');
       }, 4500);
    
       setTimeout(function() { 
        ioText.classList.add('hide');
        ioText.classList.remove('show');
       }, 5500);
    
       setTimeout(function() { 
        ioThree.classList.add('hide');
        ioThree.classList.remove('show');
       }, 7500);
    }
}

opening();

  // fade in on scroll
    AOS.init({
        offset: 200, 
        delay: 0,
        duration: 1000, 
        easing: 'ease', 
        once: false,
        mirror: false,
        anchorPlacement: 'top-bottom'
      });


    // overlay nav
    const logoBtn = document.querySelector('.header-logo');
    const exitBtn = document.querySelector('.overlay-exit');
    const overlay = document.querySelector('.overlay-nav');

    logoBtn.addEventListener('click', event => {
      overlay.classList.add('overlay__show');
      overlay.classList.remove('overlay__hidden');
    })

    exitBtn.addEventListener('click', event => {
      overlay.classList.add('overlay__hidden');
      overlay.classList.remove('overlay__show');
    })
    

    


    // accordian
    const accordionBtns = document.querySelectorAll(".accordion");

    accordionBtns.forEach((accordion) => {
      accordion.onclick = function () {
        this.classList.toggle("is-open");
        let content = this.nextElementSibling;
        if (content.style.maxHeight) {
          //this is if the accordion is open
          // content.classList.add("acc__hide");
          // content.classList.remove("acc__show");
          content.style.maxHeight = null;
        } else {
          //if the accordion is currently closed
          // content.classList.add("acc__show");
          // content.classList.remove("acc__hide");
          content.style.maxHeight = content.scrollHeight + "px";
        }
      };
    });


    /* Lazy Load Initialiser */
    var lazyLoadInstance = new LazyLoad({
    });
    
    
}());

